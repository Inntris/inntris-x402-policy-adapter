import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';

const candidate = '665e793b253c7c771e497ebc9eba2aa87356e270';
const directory = '.dev/pulse-validation-665e793-20260908';
const root = process.cwd();
const phase = process.argv[2];
const reportPath = join(directory, 'validation.json');
const gitArgs = ['-c', `safe.directory=${root.replaceAll('\\', '/')}`];
const environment = { ...process.env, GIT_OPTIONAL_LOCKS: '0', PYTHONDONTWRITEBYTECODE: '1',
  PATH: ['C:\\Users\\Ronal\\AppData\\Local\\Temp\\inntris-pnpm10-bin', 'C:\\Users\\Ronal\\.cache\\codex-runtimes\\node-v24.18.0\\node-v24.18.0-win-x64', resolve('.venv/Scripts'), process.env.PATH].join(';'),
  INNTRIS_TEST_POSTGRES_URL: 'postgresql://inntris@127.0.0.1:55483/inntris_test',
};
const git = (...args) => {
  const result = spawnSync('git', [...gitArgs, ...args], { encoding: 'utf8', env: environment, windowsHide: true });
  if (result.status !== 0) throw new Error(`git ${args.join(' ')}: ${result.stderr}`);
  return result.stdout.trim();
};
const hash = value => createHash('sha256').update(value).digest('hex');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
async function snapshot() {
  const paths = git('ls-files', '-z').split('\0').filter(Boolean);
  const files = {};
  for (const path of paths) files[path] = hash(await readFile(path));
  return files;
}
const protectedIgnored = ['.dev/pulse-remediation-red.json', '.dev/pulse-remediation-green.json'];
let report;
if (phase === 'local') {
  if (git('rev-parse', 'HEAD') !== candidate || git('status', '--porcelain=v1', '--untracked-files=all') !== '') throw new Error('Candidate precondition failed');
  const before = await snapshot();
  report = { sourceRevision: candidate, branch: git('branch', '--show-current'), startedAt: new Date().toISOString(),
    status: 'in-progress', workingTreeBefore: 'clean', environment: { node: process.version, platform: process.platform, architecture: process.arch,
      postgres: '18.1 local; CI uses 18.4', database: 'isolated loopback port 55483, synthetic data, trust authentication',
      pathPrefixes: environment.PATH.split(';').slice(0,3), PYTHONDONTWRITEBYTECODE: '1', GIT_OPTIONAL_LOCKS: '0' },
    before, historicalIgnoredHashes: Object.fromEntries(await Promise.all(protectedIgnored.map(async path => [path, hash(await readFile(path))]))), checks: [] };
  await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
} else {
  report = await json(reportPath);
  if (report.status === 'failed') throw new Error('A previous check failed; no further checks may run');
}
async function save() { await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n'); }
async function invariant() {
  if (git('rev-parse', 'HEAD') !== candidate || git('status', '--porcelain=v1', '--untracked-files=all') !== '') throw new Error('Tracked revision or clean-tree invariant changed');
  if (JSON.stringify(await snapshot()) !== JSON.stringify(report.before)) throw new Error('Tracked file bytes changed');
  for (const [path, expected] of Object.entries(report.historicalIgnoredHashes)) if (hash(await readFile(path)) !== expected) throw new Error(`Historical report changed: ${path}`);
}
async function check(name, command, options = {}) {
  await invariant();
  const entry = { name, command, startedAt: new Date().toISOString() };
  report.checks.push(entry); await save();
  console.log(`START ${entry.startedAt} ${name}: ${command}`);
  const output = [];
  const stdout = [];
  const exitCode = await new Promise(resolveExit => {
    const child = spawn(command, { shell: process.env.ComSpec || 'cmd.exe', env: environment, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    child.stdout.on('data', chunk => { output.push(chunk); stdout.push(chunk); }); child.stderr.on('data', chunk => output.push(chunk));
    child.on('error', error => output.push(Buffer.from(String(error))));
    child.on('close', code => resolveExit(code ?? -1));
  });
  const bytes = Buffer.concat(output);
  const text = bytes.toString('utf8').replace(/\x1b\[[0-9;]*m/g, '');
  Object.assign(entry, { endedAt: new Date().toISOString(), exitCode, log: `${name}.log`, logSha256: hash(bytes),
    resultCounts: { vitest: [...text.matchAll(/Tests\s+([^\r\n]+)/g)].map(match => match[1].trim()),
      python: [...text.matchAll(/Ran (\d+) tests?/g)].map(match => Number(match[1])) } });
  await writeFile(join(directory, entry.log), bytes, { flag: 'wx' });
  if (options.vitest) { const details = await json(join(directory, options.vitest)); entry.resultCounts.summary = {
    total: details.numTotalTests, passed: details.numPassedTests, failed: details.numFailedTests, pending: details.numPendingTests }; }
  // Audit tools put their JSON on stdout and human summaries on stderr.
  if (options.json && exitCode === 0) entry.structuredResult = JSON.parse(Buffer.concat(stdout).toString('utf8'));
  await save();
  console.log(`END ${entry.endedAt} ${name}: exit ${exitCode}; ${JSON.stringify(entry.resultCounts)}`);
  if (exitCode !== 0) { console.log(text.slice(-14000)); throw new Error(`Check failed: ${name}`); }
  await invariant();
}
const dbDir = `${directory}/postgres`;
const pg = '"C:\\Program Files\\PostgreSQL\\18\\bin\\';
let databaseStarted = false;
try {
  await invariant();
  if (phase === 'resume-local') {
    const pending = report.checks.filter(entry => entry.exitCode === undefined);
    if (pending.length !== 1 || pending[0].name !== 'postgres-start' || report.checks.some(entry => entry.exitCode !== undefined && entry.exitCode !== 0)) throw new Error('Unexpected continuation checkpoint');
    await copyFile(reportPath, join(directory, 'interrupted-checkpoint.json'), 1);
    report.interruption = { observedAt: new Date().toISOString(), detail: 'Original validation process absent; isolated database no longer listening. PostgreSQL log proves initial readiness, but command end time and exit status were not captured. Preserve unknown status; resume remaining checks without treating startup as passed.' };
    pending[0].disposition = 'incomplete; process ended without a captured exit status';
    report.resumeAt = new Date().toISOString();
    await save();
    databaseStarted = true;
    await check('postgres-start-resumed', `${pg}pg_ctl.exe" -D ${dbDir} -l ${directory}/postgres-resumed-server.log -o "-h 127.0.0.1 -p 55483" -w start`);
    await check('postgres-createdb', `${pg}createdb.exe" -h 127.0.0.1 -p 55483 -U inntris inntris_test`);
    await check('integration', 'pnpm test:integration');
    await check('kya', 'pnpm test:kya');
    await check('postgres-stop', `${pg}pg_ctl.exe" -D ${dbDir} -m fast -w stop`);
    databaseStarted = false;
    await check('conformance', 'pnpm conformance');
    await check('conformance-kya', 'pnpm conformance:kya');
    await check('evidence', 'pnpm evidence:verify');
    await check('evidence-kya', 'pnpm evidence:kya:verify');
    report.localChecksComplete = true;
  } else
  if (phase === 'local') {
    await check('runtimes', 'node --version && pnpm --version && python --version');
    await check('install', 'pnpm install --frozen-lockfile');
    await check('format', 'pnpm format:check');
    await check('lint', 'pnpm lint');
    await check('typecheck', 'pnpm typecheck');
    await check('build', 'pnpm build');
    await check('evaluator', 'pnpm test:pulse');
    await check('adversarial', `.\\node_modules\\.bin\\vitest.CMD run --config vitest.pulse.config.ts test/pulse/adversarial.test.ts --reporter=json --outputFile=${directory}/fresh-adversarial.json`, { vitest: 'fresh-adversarial.json' });
    await check('python-boundary', 'python -B packages/pulse-conformance-evaluator/python/adversarial_test.py');
    await check('structured-bridge', 'python -B packages/pulse-conformance-evaluator/python/self_test.py');
    await check('unit', 'pnpm test:unit');
    await check('production-ap2', 'pnpm test:ap2-official');
    await check('postgres-init', `${pg}initdb.exe" -D ${dbDir} -U inntris -A trust --encoding=UTF8 --no-locale`);
    databaseStarted = true;
    await check('postgres-start', `powershell.exe -NoProfile -ExecutionPolicy Bypass -File ${directory}/postgres-start.ps1 -DataDirectory ${dbDir}`);
    await check('postgres-createdb', `${pg}createdb.exe" -h 127.0.0.1 -p 55483 -U inntris inntris_test`);
    await check('integration', 'pnpm test:integration');
    await check('kya', 'pnpm test:kya');
    await check('postgres-stop', `${pg}pg_ctl.exe" -D ${dbDir} -m fast -w stop`);
    databaseStarted = false;
    await check('conformance', 'pnpm conformance');
    await check('conformance-kya', 'pnpm conformance:kya');
    await check('evidence', 'pnpm evidence:verify');
    await check('evidence-kya', 'pnpm evidence:kya:verify');
    report.localChecksComplete = true;
  } else if (phase === 'audits') {
    if (!report.localChecksComplete) throw new Error('Local checks must finish first');
    await check('dependency-audit', 'pnpm audit --prod --audit-level high --json', { json: true });
    await check('python-audit', 'python -B -m pip_audit --timeout 20 --progress-spinner off --format json', { json: true });
    report.auditsComplete = true;
  } else if (phase === 'replay') {
    if (!report.auditsComplete) throw new Error('Audits must finish first');
    const source = 'C:/Users/Ronal/AppData/Local/Temp/inntris-pulse-qualified-8d2d5158eb9d457b8eeda768446baec7/frozen-cases.json';
    report.fixtureRawSha256 = hash(await readFile(source));
    await check('blind', `node packages/pulse-conformance-evaluator/dist/cli.js blind --source "${source}" --output ${directory}/blinded.json`);
    const command = `node packages/pulse-conformance-evaluator/dist/cli.js evaluate --input ${directory}/blinded.json --record ${directory}/reproduction.json --implementation-commit ${candidate} --organization Inntris --published-url https://github.com/Inntris/inntris-x402-policy-adapter --python .venv/Scripts/python.exe --notes "Fresh local validation of frozen candidate; no external Pulse validator; record not yet published"`;
    await check('replay', command);
    // Only after a new independent result is frozen do we open our historical result.
    const newBytes = await readFile(join(directory, 'reproduction.json'));
    report.reproductionSha256 = hash(newBytes);
    const current = JSON.parse(newBytes);
    const prior = await json('evidence/pulse-ap2-x402-v0.3/reproduction.json');
    const comparisonStarted = new Date().toISOString();
    const priorById = new Map(prior.results.map(result => [result.id, result]));
    const differences = current.results.filter(result => JSON.stringify(result) !== JSON.stringify(priorById.get(result.id)));
    report.corpusComparison = { startedAt: comparisonStarted, endedAt: new Date().toISOString(),
      comparison: 'Inntris historical independent results only; no fixture expected values',
      total: current.results.length, unique: new Set(current.results.map(result => result.id)).size,
      accepted: current.results.filter(result => result.decision === 'accept').length,
      rejected: current.results.filter(result => result.decision === 'reject').length, differences };
    if (current.results.length !== 80 || report.corpusComparison.unique !== 80 || differences.length) throw new Error('Corpus comparison failed');
    report.status = 'passed';
    report.finishedAt = new Date().toISOString();
  } else throw new Error('Unknown validation phase');
} catch (error) {
  report.status = 'failed'; report.error = String(error); report.finishedAt = new Date().toISOString();
  process.exitCode = 1;
  console.error(String(error));
} finally {
  if (databaseStarted) {
    const stopped = spawnSync(`${pg}pg_ctl.exe" -D ${dbDir} -m fast -w stop`, { shell: process.env.ComSpec || 'cmd.exe', encoding: 'utf8', env: environment, windowsHide: true });
    report.databaseCleanup = { exitCode: stopped.status, output: stopped.stdout + stopped.stderr };
  }
  report.after = await snapshot();
  report.headAfter = git('rev-parse', 'HEAD');
  report.workingTreeAfter = git('status', '--porcelain=v1', '--untracked-files=all') || 'clean';
  report.trackedFilesByteIdentical = JSON.stringify(report.before) === JSON.stringify(report.after);
  report.historicalReportsPreserved = (await Promise.all(Object.entries(report.historicalIgnoredHashes).map(async ([path, expected]) => hash(await readFile(path)) === expected))).every(Boolean);
  await save();
  console.log(JSON.stringify({ status: report.status, localChecksComplete: report.localChecksComplete, auditsComplete: report.auditsComplete,
    trackedFilesByteIdentical: report.trackedFilesByteIdentical, workingTreeAfter: report.workingTreeAfter, corpusComparison: report.corpusComparison }, null, 2));
}

param([Parameter(Mandatory=$true)][string]$DataDirectory)
$ErrorActionPreference = 'Stop'
$resolved = (Resolve-Path -LiteralPath $DataDirectory).Path
$scope = (Resolve-Path -LiteralPath '.dev/pulse-validation-665e793-20260908').Path
if (-not $resolved.StartsWith($scope + [IO.Path]::DirectorySeparatorChar)) { throw 'Unexpected PostgreSQL data directory' }
Start-Process -FilePath 'C:\Program Files\PostgreSQL\18\bin\postgres.exe' -ArgumentList @('-D',('"' + $resolved + '"'),'-h','127.0.0.1','-p','55483') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $scope 'postgres-stdout.log') -RedirectStandardError (Join-Path $scope 'postgres-stderr.log')
for ($attempt = 0; $attempt -lt 15; $attempt++) {
    & 'C:\Program Files\PostgreSQL\18\bin\pg_isready.exe' -h 127.0.0.1 -p 55483 -U inntris
    if ($LASTEXITCODE -eq 0) { exit 0 }
    Start-Sleep -Seconds 1
}
throw 'Isolated PostgreSQL instance did not become ready'

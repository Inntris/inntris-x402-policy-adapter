# QUALIFIED

Local qualification of source revision `665e793b253c7c771e497ebc9eba2aa87356e270`, completed 9 September 2026.

This is a composite of completed checks on one byte identical committed source revision, not a claim of one uninterrupted run. It supersedes the earlier caveated green report for validation provenance without changing or erasing that report or historical red evidence. This report is an ignored local artefact, not a commit, release or external Pulse qualification claim. No evaluator or test logic changed.

## Result

All mandatory local commands completed successfully. PostgreSQL integration: 29 passed. KYA: 62 passed. No skips in either suite. Conformance: all five rails including AP2 passed, with exact action mutations rejected. KYA conformance: one passed. Both evidence verifiers passed. The high severity production dependency audit passed with seven moderate findings still present. Python audit: 45 dependencies, zero known findings.

The carried forward full evaluator suite has 89 TypeScript tests. The separate 65 adversarial/boundary/specification tests overlap that suite and are not added to its total. Python boundary: 16 passed; the structured self test includes those same tests. Repository unit: 168 passed. Both AP2 bridge self tests passed. Frozen installation, formatting, lint, type checking and build passed on this exact source revision on 8 September.

Blinded corpus: 80 executed exactly once, 80 unchanged, zero missing, zero indeterminate, zero unexpected differences; 20 accept and 60 reject. Decisions, ordered failure lists and input hashes all matched the previous Inntris result. No fixture expected values were read for adaptation and no external Pulse validator ran.

No new security counterexample was demonstrated by these executions. The previously documented limitations concerning undisclosed restrictive claims, resource authenticity and failure applicability after schema rejection remain. Passing these local gates does not establish production readiness, live settlement, absence of undiscovered vulnerabilities, hosted CI success or external endorsement.

## Environment and integrity

Candidate branch: `codex/pulse-ap2-x402-adversarial-remediation`. All 379 tracked file SHA256 hashes match the recorded baseline. HEAD and the working tree remain unchanged and clean. Original helper files and prior evidence are preserved with hashes in the linked manifests.

Runner: Windows amd64, Node 24.18.0, pnpm 10.18.1, Python 3.12.3. Database: PostgreSQL 18.4, Alpine 3.24.1, x86_64, Linux kernel 6.6.87.2-microsoft-standard-WSL2. This uses the repository's exact pinned CI image but not the complete Ubuntu hosted runner environment. The latest user authorisation permits Docker instead of the previously requested native WSL route.

Image: `postgres:18.4-alpine@sha256:9a8afca54e7861fd90fab5fdf4c42477a6b1cb7d293595148e674e0a3181de15`. Isolated synthetic test database on loopback port 25432. Startup and readiness each exited zero. The test container was stopped after the database checks; containers and previous artefacts were preserved, not deleted. Docker Desktop itself was not stopped or reconfigured.

## Commands and times

All timestamps are UTC. The manifests retain full commands, output log paths, hashes and counts, including setup and unsuccessful attempts. For the replay's full arguments use the final manifest; shorthand below does not replace that captured command.

| Check | Command | Start | End | Exit |
| :--- | :--- | :--- | :--- | :--- |
| install | `pnpm install --frozen-lockfile` | 2026-09-08T16:29:14.184Z | 2026-09-08T16:29:17.043Z | 0 |
| format | `pnpm format:check` | 2026-09-08T16:29:18.126Z | 2026-09-08T16:29:27.704Z | 0 |
| lint | `pnpm lint` | 2026-09-08T16:29:28.696Z | 2026-09-08T16:31:14.468Z | 0 |
| typecheck | `pnpm typecheck` | 2026-09-08T16:31:15.69Z | 2026-09-08T16:31:18.703Z | 0 |
| build | `pnpm build` | 2026-09-08T16:31:19.701Z | 2026-09-08T16:31:20.773Z | 0 |
| evaluator | `pnpm test:pulse` | 2026-09-08T16:31:21.899Z | 2026-09-08T16:32:36.366Z | 0 |
| adversarial | `.\node_modules\.bin\vitest.CMD run --config vitest.pulse.config.ts test/pulse/adversarial.test.ts --reporter=json --outputFile=.dev/pulse-validation-665e793-20260908/fresh-adversarial.json` | 2026-09-08T16:32:37.453Z | 2026-09-08T16:33:25.96Z | 0 |
| python-boundary | `python -B packages/pulse-conformance-evaluator/python/adversarial_test.py` | 2026-09-08T16:33:26.863Z | 2026-09-08T16:33:27.635Z | 0 |
| structured-bridge | `python -B packages/pulse-conformance-evaluator/python/self_test.py` | 2026-09-08T16:33:28.619Z | 2026-09-08T16:33:29.388Z | 0 |
| unit | `pnpm test:unit` | 2026-09-08T16:33:30.37Z | 2026-09-08T16:33:43.964Z | 0 |
| production-ap2 | `pnpm test:ap2-official` | 2026-09-08T16:33:44.901Z | 2026-09-08T16:33:47.045Z | 0 |
| postgres-start | `docker start inntris-validation-665e793-20260909` | 2026-09-09T07:17:48.046Z | 2026-09-09T07:17:48.509Z | 0 |
| postgres-ready | `docker exec inntris-validation-665e793-20260909 sh -c "for i in $(seq 1 30); do pg_isready -U inntris -d inntris_test && exit 0; sleep 1; done; exit 1"` | 2026-09-09T07:17:48.757Z | 2026-09-09T07:17:50.038Z | 0 |
| postgres-version | `docker exec inntris-validation-665e793-20260909 psql -U inntris -d inntris_test -c "SELECT version();"` | 2026-09-09T07:17:50.303Z | 2026-09-09T07:17:50.574Z | 0 |
| integration | `pnpm test:integration` | 2026-09-09T07:17:50.82Z | 2026-09-09T07:18:15.166Z | 0 |
| kya | `pnpm test:kya` | 2026-09-09T07:18:15.449Z | 2026-09-09T07:18:32.66Z | 0 |
| conformance | `pnpm conformance` | 2026-09-09T07:18:32.901Z | 2026-09-09T07:18:34.619Z | 0 |
| conformance-kya | `pnpm conformance:kya` | 2026-09-09T07:18:34.861Z | 2026-09-09T07:18:38.676Z | 0 |
| evidence | `pnpm evidence:verify` | 2026-09-09T07:18:38.927Z | 2026-09-09T07:18:39.966Z | 0 |
| evidence-kya | `pnpm evidence:kya:verify` | 2026-09-09T07:18:40.211Z | 2026-09-09T07:18:41.446Z | 0 |
| esbuild-smoke | `node .dev/pulse-docker-665e793-20260909/esbuild-smoke.mjs` | 2026-09-09T07:18:42.37Z | 2026-09-09T07:18:42.66Z | 0 |
| dependency-audit | `pnpm audit --prod --audit-level high` | 2026-09-09T07:20:06.366Z | 2026-09-09T07:20:07.424Z | 0 |
| python-audit | `python -B -m pip_audit --timeout 20 --progress-spinner off --format json` | 2026-09-09T07:20:07.693Z | 2026-09-09T07:20:17.1Z | 0 |
| blind | `node packages/pulse-conformance-evaluator/dist/cli.js blind [full arguments in manifest]` | 2026-09-09T07:20:17.363Z | 2026-09-09T07:20:18.725Z | 0 |
| replay | `node packages/pulse-conformance-evaluator/dist/cli.js evaluate [full arguments in manifest]` | 2026-09-09T07:20:18.973Z | 2026-09-09T07:20:46.001Z | 0 |
| compare | `node .dev/pulse-audit-replay-665e793-20260909/compare.mjs` | 2026-09-09T07:20:46.252Z | 2026-09-09T07:20:46.351Z | 0 |

## Audit findings and threshold semantics

The exact requested gate `pnpm audit --prod --audit-level high` exited zero at 07:20:07.424Z. The separate JSON reporting command exited one despite zero high/critical findings. Installed pnpm 10.18.1 source at `dist/pnpm.cjs:133722` returns nonzero for any finding in JSON mode; the severity threshold is applied subsequently only in the non JSON branch at line 133729. No findings were suppressed, ignored or fixed. The original JSON report and unsuccessful runner status are preserved.

Current findings: seven moderate, zero low, zero high, zero critical. Preserved baseline: four moderate. The three additional Hono advisories were published on 8 September. All seven dependency versions are inherited from local `origin/main` at `1f48fcff63d6373e88e97b5e7c49450682a64366`; all package manifests, workspace configuration, lockfile and Python security overrides are unchanged. Both revisions have lockfile Git blob `655235872ed1cf4f5dd85f30dc516e4496ba8183`. This attribution does not waive findings or establish exploitability in a deployment.

| Advisory | Package and version | Path | Published patch threshold |
| :--- | :--- | :--- | :--- |
| [GHSA-x5fp-wj9c-mxmx](https://github.com/advisories/GHSA-x5fp-wj9c-mxmx) | qs 6.15.3 | packages__a2a-settlement-gate>@a2a-js/sdk>express>qs | >=6.16.0 |
| [GHSA-4mjr-xmp4-gh2g](https://github.com/advisories/GHSA-4mjr-xmp4-gh2g) | qs 6.15.3 | packages__a2a-settlement-gate>@a2a-js/sdk>express>qs | >=6.16.0 |
| [GHSA-w2qp-rph6-63g4](https://github.com/advisories/GHSA-w2qp-rph6-63g4) | fastify 5.10.0 | apps__demo-api>fastify | >=5.12.1 |
| [GHSA-3m5p-2c4r-xxw2](https://github.com/advisories/GHSA-3m5p-2c4r-xxw2) | fastify 5.10.0 | apps__demo-api>fastify | >=5.12.1 |
| [GHSA-gqvv-2mrq-wpjv](https://github.com/advisories/GHSA-gqvv-2mrq-wpjv) | hono 4.13.1 | packages__kya-os-authority>@modelcontextprotocol/sdk>hono | >=4.13.5 |
| [GHSA-g6gw-c38x-mqfc](https://github.com/advisories/GHSA-g6gw-c38x-mqfc) | hono 4.13.1 | packages__kya-os-authority>@modelcontextprotocol/sdk>hono | >=4.13.5 |
| [GHSA-crvj-82cr-hjcx](https://github.com/advisories/GHSA-crvj-82cr-hjcx) | hono 4.13.1 | packages__kya-os-authority>@modelcontextprotocol/sdk>hono | >=4.13.5 |

Python command: `python -B -m pip_audit --timeout 20 --progress-spinner off --format json`. Exit zero, zero findings among 45 dependencies, zero fixes. This matches the prior zero findings result.

The ignored esbuild lifecycle script warning is explained by tracked `onlyBuiltDependencies: []`. No scripts were enabled. The installed esbuild 0.28.1 native executable passed the bounded TypeScript transform check. Root build uses TypeScript's `tsc -b`. This runtime evidence does not replace the security audit.

## Blinding and frozen output

Raw fixture SHA256: `8f40be1bdc3d4458f758100e91b418b6a335c5d8d358723f118e2d3e1ad84ee0`.

Fresh reproduction SHA256: `4f751cdb24792ba27880a04847b8af0f6e998c23db201599cd8ab74ba5caaa05`.

Output execution ended 07:20:46.001Z. Output hash was persisted at 07:20:46.125Z. Comparison began only at 07:20:46.252Z. Comparator was authored and hashed before any new output was computed, and was not edited afterwards. It reads only the previous Inntris record, not fixture expectations or reference verifier implementation.

Prior Inntris record SHA256: `857bade1fe50fb1fc4ecd8c8aefbd2b6563fbb0395a1d59ff99afb62bde7f159`. Comparison reported zero differences. Both records contain exactly 80 unique identifiers; all current decisions are accept or reject.

## Preserved attempts and evidence chain

1. [Exact source validation on 8 September](../pulse-validation-665e793-20260908/validation.json): passing evaluator and repository checks; incomplete original PostgreSQL startup and later Windows restricted token failure are not relabelled as passes.
2. [Native WSL preparation](../pulse-native-665e793-20260908/validation.json): apt exited 100 because dpkg was already interrupted. No repair performed.
3. [Original Docker helper attempt](../pulse-continuation-665e793-20260908/validation.json): Windows rejected port 55484. Read only inspection confirmed it lies in reserved range 55459 through 55558. Original helpers remain ignored and byte identical.
4. [Database and conformance run](../pulse-docker-665e793-20260909/validation.json): separate tooling uses unreserved port 25432; all database/conformance/evidence gates passed. JSON audit reporting exited one and stopped that runner.
5. [Exact audit gate and blinded replay](../pulse-audit-replay-665e793-20260909/validation.json): exact requested audit command, Python audit and corpus replay passed, with fresh output frozen before comparison.
6. [Fresh reproduction](../pulse-audit-replay-665e793-20260909/reproduction.json) and [comparison](../pulse-audit-replay-665e793-20260909/compare.log).

No prior failed report was overwritten to make it green. New tooling was kept separate and its content hashes were checked during execution. The prior historical red and caveated green are unchanged.

## Handoff

No tracked files changed. No evidence commit, push, PR, merge, release or external validator run occurred. This consolidated report is prepared for review only. An evidence only follow up must identify the tested source as `665e793b253c7c771e497ebc9eba2aa87356e270` and contain no evaluator or test logic changes. Hosted quality, CodeQL and secret scanning remain separate merge gates and are not claimed by this local result.

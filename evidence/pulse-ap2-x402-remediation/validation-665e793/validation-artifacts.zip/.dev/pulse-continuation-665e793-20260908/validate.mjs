import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { resolve, join } from 'node:path';

const revision = '665e793b253c7c771e497ebc9eba2aa87356e270';
const directory = '.dev/pulse-continuation-665e793-20260908';
const previousDirectory = '.dev/pulse-validation-665e793-20260908';
const root = process.cwd();
const image = 'postgres:18.4-alpine@sha256:9a8afca54e7861fd90fab5fdf4c42477a6b1cb7d293595148e674e0a3181de15';
const container = 'inntris-validation-665e793-20260908';
const env = { ...process.env, GIT_OPTIONAL_LOCKS: '0', PYTHONDONTWRITEBYTECODE: '1',
  PATH: ['C:\\Users\\Ronal\\AppData\\Local\\Temp\\inntris-pnpm10-bin', 'C:\\Users\\Ronal\\.cache\\codex-runtimes\\node-v24.18.0\\node-v24.18.0-win-x64', resolve('.venv/Scripts'), process.env.PATH].join(';'),
  INNTRIS_TEST_POSTGRES_URL: 'postgresql://inntris:inntris-test@127.0.0.1:55484/inntris_test' };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const git = (...args) => {
  const r = spawnSync('git', ['-c', `safe.directory=${root.replaceAll('\\','/')}`, ...args], { env, encoding: 'utf8', windowsHide: true });
  if (r.status !== 0) throw Error(r.stderr);
  return r.stdout.trim();
};
async function hashes(paths) { return Object.fromEntries(await Promise.all(paths.map(async path => [path, hash(await readFile(path))]))); }
const tracked = git('ls-files', '-z').split('\0').filter(Boolean);
const before = await hashes(tracked);
if (git('rev-parse','HEAD') !== revision || git('status','--porcelain=v1','--untracked-files=all')) throw Error('Candidate must be exact and clean');
const protectedPaths = ['.dev/pulse-remediation-red.json', '.dev/pulse-remediation-green.json',
  ...(await readdir(previousDirectory, {withFileTypes:true})).filter(e=>e.isFile()).map(e=>join(previousDirectory,e.name))];
const preserved = await hashes(protectedPaths);
const previous = JSON.parse(await readFile(join(previousDirectory,'validation.json'),'utf8'));
if (JSON.stringify(before) !== JSON.stringify(previous.before)) throw Error('Source bytes differ from previous validation');
const report = { revision, startedAt: new Date().toISOString(), status:'running', before, preserved,
  previousReport: join(previousDirectory,'validation.json'), previousReportSha256: preserved[join(previousDirectory,'validation.json')],
  carriedForward: previous.checks.filter(c=>c.exitCode===0),
  environment: {node:process.version, platform:process.platform, databaseImage:image, databasePort:55484,
    deviation:'Test runner and existing dependencies remain on Windows; PostgreSQL uses the exact Linux image pinned by CI.'}, checks:[] };
const reportPath = join(directory,'validation.json');
await writeFile(reportPath,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
const save = () => writeFile(reportPath,JSON.stringify(report,null,2)+'\n');
async function invariant() {
  if (git('rev-parse','HEAD') !== revision || git('status','--porcelain=v1','--untracked-files=all')) throw Error('Revision or clean tree changed');
  if (JSON.stringify(before)!==JSON.stringify(await hashes(tracked))) throw Error('Tracked bytes changed');
  if (JSON.stringify(preserved)!==JSON.stringify(await hashes(protectedPaths))) throw Error('Historical evidence changed');
}
async function check(name,command,{json=false}={}) {
  await invariant();
  const entry={name,command,startedAt:new Date().toISOString()}; report.checks.push(entry); await save();
  console.log(`START ${entry.startedAt} ${name}: ${command}`);
  const out=[],err=[];
  const code=await new Promise(done=>{
    const child=spawn(command,{shell:process.env.ComSpec||'cmd.exe',env,windowsHide:true,stdio:['ignore','pipe','pipe']});
    child.stdout.on('data',b=>out.push(b)); child.stderr.on('data',b=>err.push(b));
    child.on('error',e=>err.push(Buffer.from(String(e)))); child.on('close',c=>done(c??-1));
  });
  const stdout=Buffer.concat(out),stderr=Buffer.concat(err);
  const output=Buffer.concat([stdout,stderr]); const text=output.toString('utf8').replace(/\x1b\[[0-9;]*m/g,'');
  Object.assign(entry,{endedAt:new Date().toISOString(),exitCode:code,log:`${name}.log`,logSha256:hash(output),
    counts:[...text.matchAll(/Tests\s+([^\r\n]+)/g)].map(m=>m[1].trim())});
  await writeFile(join(directory,entry.log),output,{flag:'wx'});
  if(json) {try {entry.result=JSON.parse(stdout.toString('utf8'));} catch {entry.jsonParseError=true;}}
  await save();console.log(`END ${entry.endedAt} ${name}: ${code}; ${JSON.stringify(entry.counts)}`);
  if(code!==0) {console.log(text.slice(-16000));throw Error(`Gate failed: ${name}`);}
  if(json && entry.jsonParseError) throw Error(`Invalid JSON output: ${name}`);
  await invariant();return stdout.toString('utf8');
}
let created=false;
try {
  await check('runtimes','node --version && pnpm --version && python --version && docker version');
  await check('postgres-pull',`docker pull ${image}`);
  const id=await check('postgres-create',`docker create --name ${container} -p 127.0.0.1:55484:5432 -e POSTGRES_USER=inntris -e POSTGRES_PASSWORD=inntris-test -e POSTGRES_DB=inntris_test --health-cmd "pg_isready -U inntris -d inntris_test" --health-interval 1s --health-timeout 5s --health-retries 30 ${image}`);
  created=true;report.containerId=id.trim();await save();
  await check('postgres-start',`docker start ${container}`);
  await check('postgres-ready',`docker exec ${container} sh -c "for i in $(seq 1 30); do pg_isready -U inntris -d inntris_test && exit 0; sleep 1; done; exit 1"`);
  await check('postgres-version',`docker exec ${container} psql -U inntris -d inntris_test -c "SELECT version();"`);
  await check('integration','pnpm test:integration');
  await check('kya','pnpm test:kya');
  await check('conformance','pnpm conformance');
  await check('conformance-kya','pnpm conformance:kya');
  await check('evidence','pnpm evidence:verify');
  await check('evidence-kya','pnpm evidence:kya:verify');
  await check('esbuild-paths','pnpm why esbuild --recursive');
  await check('esbuild-smoke',`node ${directory}/esbuild-smoke.mjs`);
  await check('dependency-audit','pnpm audit --prod --audit-level high --json',{json:true});
  await check('python-audit','python -B -m pip_audit --timeout 20 --progress-spinner off --format json',{json:true});
  const fixture='C:/Users/Ronal/AppData/Local/Temp/inntris-pulse-qualified-8d2d5158eb9d457b8eeda768446baec7/frozen-cases.json';
  report.fixtureSha256=hash(await readFile(fixture));
  if(report.fixtureSha256!=='8f40be1bdc3d4458f758100e91b418b6a335c5d8d358723f118e2d3e1ad84ee0')throw Error('Raw fixture hash mismatch');
  await check('blind',`node packages/pulse-conformance-evaluator/dist/cli.js blind --source "${fixture}" --output ${directory}/blinded.json`);
  await check('replay',`node packages/pulse-conformance-evaluator/dist/cli.js evaluate --input ${directory}/blinded.json --record ${directory}/reproduction.json --implementation-commit ${revision} --organization Inntris --published-url https://github.com/Inntris/inntris-x402-policy-adapter --python .venv/Scripts/python.exe --notes "Local validation continuation; no external validator; unpublished record"`);
  report.reproductionSha256=hash(await readFile(join(directory,'reproduction.json')));
  report.recordFrozenAt=new Date().toISOString();await save();
  await check('compare',`node ${directory}/compare.mjs`,{json:true});
  report.status='passed';
} catch(error) {report.status='failed';report.error=String(error);process.exitCode=1;console.error(String(error));}
finally {
  if(created) {
    const cleanup={command:`docker stop ${container}`,startedAt:new Date().toISOString()};
    const r=spawnSync(cleanup.command,{shell:process.env.ComSpec||'cmd.exe',env,encoding:'utf8',windowsHide:true,timeout:30000});
    Object.assign(cleanup,{endedAt:new Date().toISOString(),exitCode:r.status,output:r.stdout+r.stderr});report.cleanup=cleanup;
    if(r.status!==0){report.status='failed';process.exitCode=1;}
  }
  report.after=await hashes(tracked);report.headAfter=git('rev-parse','HEAD');
  report.workingTreeAfter=git('status','--porcelain=v1','--untracked-files=all')||'clean';
  report.trackedBytesUnchanged=JSON.stringify(before)===JSON.stringify(report.after);
  report.historicalEvidenceUnchanged=JSON.stringify(preserved)===JSON.stringify(await hashes(protectedPaths));
  if(!report.trackedBytesUnchanged||!report.historicalEvidenceUnchanged||report.workingTreeAfter!=='clean'||report.headAfter!==revision){report.status='failed';process.exitCode=1;}
  report.finishedAt=new Date().toISOString();await save();
  console.log(JSON.stringify({status:report.status,error:report.error,trackedBytesUnchanged:report.trackedBytesUnchanged,historicalEvidenceUnchanged:report.historicalEvidenceUnchanged,workingTreeAfter:report.workingTreeAfter}));
}

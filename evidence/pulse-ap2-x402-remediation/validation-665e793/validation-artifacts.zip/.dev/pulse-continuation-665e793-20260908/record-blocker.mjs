import { spawnSync } from 'node:child_process';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const directory='.dev/pulse-continuation-665e793-20260908';
const previousDirectory='.dev/pulse-validation-665e793-20260908';
const git=(...args)=>{const r=spawnSync('git',['-c',`safe.directory=${process.cwd().replaceAll('\\','/')}`,...args],{encoding:'utf8',env:{...process.env,GIT_OPTIONAL_LOCKS:'0'},windowsHide:true});if(r.status!==0)throw Error(r.stderr);return r.stdout.trim();};
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const previousBytes=await readFile(join(previousDirectory,'validation.json'));
const previous=JSON.parse(previousBytes);
const tracked={};for(const path of git('ls-files','-z').split('\0').filter(Boolean))tracked[path]=sha(await readFile(path));
const preserved={};
for(const path of ['.dev/pulse-remediation-red.json','.dev/pulse-remediation-green.json',...(await readdir(previousDirectory,{withFileTypes:true})).filter(e=>e.isFile()).map(e=>join(previousDirectory,e.name))])preserved[path]=sha(await readFile(path));
for(const [path,expected] of Object.entries(previous.historicalIgnoredHashes))if(preserved[path]!==expected)throw Error('Historical report changed');
const smoke={command:`node ${directory}/esbuild-smoke.mjs`,startedAt:new Date().toISOString(),purpose:'Bounded diagnostic only; not a completed qualification gate'};
const r=spawnSync(process.execPath,[`${directory}/esbuild-smoke.mjs`],{encoding:'utf8',windowsHide:true});
Object.assign(smoke,{endedAt:new Date().toISOString(),exitCode:r.status,output:r.stdout+r.stderr});
const head=git('rev-parse','HEAD'),status=git('status','--porcelain=v1','--untracked-files=all');
const report={status:'blocked-before-qualification',recordedAt:new Date().toISOString(),head,workingTree:status||'clean',
  trackedBytesUnchangedFromPreviousValidation:JSON.stringify(tracked)===JSON.stringify(previous.before),trackedFileHashes:tracked,
  previousReportSha256:sha(previousBytes),preservedFileHashes:preserved,
  environment:{wsl:'Ubuntu starts successfully; no PostgreSQL installed; apt offers 18.6 and 18.3, not CI 18.4',docker:'Installed Docker Desktop 4.55.0 backend failed to start'},
  blocker:{timestamp:'2026-09-08T21:34:58.470294900Z',source:'Docker backend error dialog log',
    error:'starting services: initializing Inference manager: listening on unix://<HOME>\\AppData\\Local\\Docker\\run\\dockerInference: remove <HOME>\\AppData\\Local\\Docker\\run\\dockerInference: The file cannot be accessed by the system. (listener: The filename, directory name, or volume label syntax is incorrect.)'},
  concurrentEnvironmentChange:{timestamp:'2026-09-08T21:35:14.608050400Z',event:'Docker log records Reset to factory defaults GUI action; no reset command issued by this validation task; actor not established'},
  startupCommand:{command:'docker desktop start',startLogTimestamp:'2026-09-08T21:34:18',endTimestampCaptured:false,exitCode:1,termination:'CLI cancelled after backend had shut down; not a PostgreSQL test failure'},
  esbuild:smoke,
  esbuildAssessment:'Repository pnpm-workspace.yaml explicitly has onlyBuiltDependencies: []; root build uses tsc -b. Smoke diagnostic checks the installed optional native executable without enabling lifecycle scripts. This does not replace the still unrun dependency audit.',
  requiredGatesExecuted:[],remaining:['PostgreSQL startup','integration','KYA','conformance','KYA conformance','evidence verification','KYA evidence verification','dependency audit','Python audit','blinded replay and comparison'],
  externalValidatorInvoked:false,qualificationClaim:false};
if(head!==previous.sourceRevision||status||!report.trackedBytesUnchangedFromPreviousValidation)throw Error('Source invariant failed');
await writeFile(`${directory}/environment-blocker.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,head,workingTree:report.workingTree,trackedBytesUnchanged:report.trackedBytesUnchangedFromPreviousValidation,esbuild:smoke},null,2));

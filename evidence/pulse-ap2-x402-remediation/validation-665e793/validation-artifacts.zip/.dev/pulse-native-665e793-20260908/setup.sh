#!/usr/bin/env bash
set -euo pipefail
base=/home/ronald/inntris-pulse-native-665e793-20260908
test ! -e "$base"
mkdir -p "$base/downloads" "$base/runtime"
cd "$base/downloads"
curl --fail --location --retry 2 -o postgresql-18.4.tar.bz2 https://ftp.postgresql.org/pub/source/v18.4/postgresql-18.4.tar.bz2
curl --fail --location -o postgresql-18.4.tar.bz2.sha256 https://ftp.postgresql.org/pub/source/v18.4/postgresql-18.4.tar.bz2.sha256
sha256sum --check postgresql-18.4.tar.bz2.sha256
tar -xjf postgresql-18.4.tar.bz2
cd postgresql-18.4
./configure --prefix="$base/runtime/postgres" --without-readline --without-icu --without-zlib
make -j4
make install
"$base/runtime/postgres/bin/postgres" --version
cd "$base/downloads"
curl --fail --location --retry 2 -o node-v24.18.0-linux-x64.tar.xz https://nodejs.org/dist/v24.18.0/node-v24.18.0-linux-x64.tar.xz
curl --fail --location -o SHASUMS256.txt https://nodejs.org/dist/v24.18.0/SHASUMS256.txt
sha256sum --check --ignore-missing SHASUMS256.txt
tar -xJf node-v24.18.0-linux-x64.tar.xz -C "$base/runtime"
export PATH="$base/runtime/node-v24.18.0-linux-x64/bin:$PATH"
npm install --prefix "$base/runtime/pnpm" --ignore-scripts --no-audit --no-fund pnpm@10.18.1
export PATH="$base/runtime/pnpm/node_modules/.bin:$PATH"
node --version
pnpm --version

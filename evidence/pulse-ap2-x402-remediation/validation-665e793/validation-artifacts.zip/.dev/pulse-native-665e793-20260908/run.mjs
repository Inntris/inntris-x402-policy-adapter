import {spawn,spawnSync} from 'node:child_process';
import {readFile,writeFile,readdir,appendFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const dir='.dev/pulse-native-665e793-20260908';
const path=join(dir,'validation.json');
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...args)=>{const r=spawnSync('git',['-c',`safe.directory=${process.cwd().replaceAll('\\','/')}`,...args],{encoding:'utf8',windowsHide:true,env:{...process.env,GIT_OPTIONAL_LOCKS:'0'}});if(r.status!==0)throw Error(r.stderr);return r.stdout.trim();};
const tracked=git('ls-files','-z').split('\0').filter(Boolean);
const hashes=async paths=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,sha(await readFile(p))])));
let report;
try{report=JSON.parse(await readFile(path,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;
 const old=JSON.parse(await readFile('.dev/pulse-validation-665e793-20260908/validation.json','utf8'));
 const protect=['.dev/pulse-remediation-red.json','.dev/pulse-remediation-green.json'];
 for(const d of ['.dev/pulse-validation-665e793-20260908','.dev/pulse-continuation-665e793-20260908'])for(const e of await readdir(d,{withFileTypes:true}))if(e.isFile())protect.push(join(d,e.name));
 const helpers=['compare.mjs','esbuild-smoke.mjs','validate.mjs','record-blocker.mjs'].map(n=>'.dev/pulse-continuation-665e793-20260908/'+n);
 report={revision:old.sourceRevision,startedAt:new Date().toISOString(),classification:'INCOMPLETE',before:old.before,preserved:await hashes(protect),
 helpers:await Promise.all(helpers.map(async p=>({path:p,sha256:sha(await readFile(p)),checkIgnore:git('check-ignore','-v','--',p),tracked:git('ls-files','--',p)}))),
 priorPassedChecks:old.checks.filter(c=>c.exitCode===0),checks:[]};
 await writeFile(path,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}
const save=()=>writeFile(path,JSON.stringify(report,null,2)+'\n');
async function invariant(){if(git('rev-parse','HEAD')!==report.revision||git('status','--porcelain=v1','--untracked-files=all'))throw Error('Revision/clean tree invariant');
 if(JSON.stringify(await hashes(tracked))!==JSON.stringify(report.before))throw Error('Tracked bytes changed');
 if(JSON.stringify(await hashes(Object.keys(report.preserved)))!==JSON.stringify(report.preserved))throw Error('Preserved evidence/tooling changed');}
await invariant();
const [name,exe,...args]=process.argv.slice(2);
if(report.checks.some(c=>c.exitCode!==0))throw Error('An earlier command was unsuccessful; preserve and stop');
if(report.checks.some(c=>c.name===name))throw Error('Duplicate command name');
const entry={name,executable:exe,args,startedAt:new Date().toISOString(),command:[exe,...args.map(a=>JSON.stringify(a))].join(' ')};
report.checks.push(entry);await save();
const log=join(dir,name+'.log');await writeFile(log,'',{flag:'wx'});
console.log(`START ${entry.startedAt} ${entry.command}`);
const out=[],err=[];
entry.exitCode=await new Promise(done=>{const c=spawn(exe,args,{windowsHide:true,stdio:['ignore','pipe','pipe']});
 c.stdout.on('data',b=>{out.push(b);process.stdout.write(b)});c.stderr.on('data',b=>{err.push(b);process.stderr.write(b)});
 c.on('error',e=>err.push(Buffer.from(String(e))));c.on('close',code=>done(code??-1));});
entry.endedAt=new Date().toISOString();const bytes=Buffer.concat([...out,...err]);await appendFile(log,bytes);
entry.log=log;entry.logSha256=sha(bytes);entry.counts=[...bytes.toString().replace(/\x1b\[[0-9;]*m/g,'').matchAll(/Tests\s+([^\r\n]+)/g)].map(m=>m[1].trim());
try{await invariant();report.integrity={head:git('rev-parse','HEAD'),workingTree:'clean',trackedFileCount:tracked.length,trackedHashesUnchanged:true,historicalEvidenceAndHelpersUnchanged:true,verifiedAt:new Date().toISOString()};}
catch(e){report.integrityError=String(e);entry.exitCode=entry.exitCode||1;}
await save();console.log(`END ${entry.endedAt} ${name} exit=${entry.exitCode}`);process.exitCode=entry.exitCode;

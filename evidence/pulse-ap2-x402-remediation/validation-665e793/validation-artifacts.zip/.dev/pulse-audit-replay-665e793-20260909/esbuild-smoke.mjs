import { readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
const require=createRequire(import.meta.url);
let count=0;
for(const name of await readdir('node_modules/.pnpm')) {
  if(!/^esbuild@[^/]+$/.test(name))continue;
  const esbuild=require(resolve('node_modules/.pnpm',name,'node_modules/esbuild'));
  const result=esbuild.transformSync('const x: number = 1',{loader:'ts'});
  if(!result.code.includes('const x = 1'))throw Error('Unexpected transform');
  console.log(JSON.stringify({package:name,version:esbuild.version,transformPassed:true}));count++;
}
if(!count)throw Error('No installed esbuild found');

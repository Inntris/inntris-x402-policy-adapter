import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const directory='.dev/pulse-audit-replay-665e793-20260909';
const report=JSON.parse(await readFile(`${directory}/validation.json`,'utf8'));
const bytes=await readFile(`${directory}/reproduction.json`);
if(createHash('sha256').update(bytes).digest('hex')!==report.reproductionSha256)throw Error('Frozen record changed');
const current=JSON.parse(bytes);
// Read only Inntris's previously frozen result, after the new result is frozen.
const priorPath='evidence/pulse-ap2-x402-v0.3/reproduction.json';
const priorBytes=await readFile(priorPath);
const prior=JSON.parse(priorBytes);
const map=new Map(prior.results.map(r=>[r.id,r]));
const differences=current.results.filter(r=>JSON.stringify(r)!==JSON.stringify(map.get(r.id)));
const summary={comparison:priorPath,priorSha256:createHash('sha256').update(priorBytes).digest('hex'),total:current.results.length,
  unique:new Set(current.results.map(r=>r.id)).size,accepted:current.results.filter(r=>r.decision==='accept').length,
  rejected:current.results.filter(r=>r.decision==='reject').length,differences};
console.log(JSON.stringify(summary,null,2));
if(summary.total!==80||summary.unique!==80||map.size!==80||differences.length)process.exitCode=1;
